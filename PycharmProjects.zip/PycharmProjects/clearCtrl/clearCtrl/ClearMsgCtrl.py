import socket

'''
    client strut
'''
class ClearClient:
    def __init__(self):
        pass

class ClearMsgCtrl:
    def __init__(self):
        self.client=[]