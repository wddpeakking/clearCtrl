import socket

class ClearUdpServer:
    def __init__(self, log):
        self.log = log
        addr = ("", 1234)
        self.udpServer = socket(socket.AF_INET,socket.SOCK_DGRAM)
        self.udpServer.bind(addr)
        self.log.Info("udp server bind finished")

    def start(self):
        pass

    def closesocket(self):
        self.udpServer.close()