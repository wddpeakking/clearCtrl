import logging
from logging.handlers import RotatingFileHandler
class Log:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(level=logging.INFO)
        filehandle = RotatingFileHandler(filename="log.txt", maxBytes=1024*6, backupCount=3)
        formatter = logging.Formatter('%(asctime)s-%(module)s-%(thread)d-%(lineno)d:%(message)s')
        filehandle.setFormatter(formatter)
        self.logger.addHandler(filehandle)
    def Degbug(self,msg):
        self.logger.debug(msg)
    def Info(self,msg):
        self.logger.info(msg)
    def Warning(self,msg):
        self.logger.warning(msg)
    def Critical(self,msg):
        self.logger.critical(msg)
